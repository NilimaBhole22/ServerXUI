import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration-details',
  templateUrl: './registration-details.component.html',
  styles: []
})
export class RegistrationDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
