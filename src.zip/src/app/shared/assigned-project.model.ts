export class AssignedProject {
    id :number;
    user :string;
    project :string;
}
