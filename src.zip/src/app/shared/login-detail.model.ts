export class LoginDetail {
    id :number;
    username :string;
    password :string;
}
