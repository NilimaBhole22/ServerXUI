import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timesheet-details',
  templateUrl: './timesheet-details.component.html',
  styles: []
})
export class TimesheetDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
