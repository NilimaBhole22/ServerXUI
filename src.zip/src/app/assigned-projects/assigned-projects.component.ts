import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assigned-projects',
  templateUrl: './assigned-projects.component.html',
  styles: []
})
export class AssignedProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
